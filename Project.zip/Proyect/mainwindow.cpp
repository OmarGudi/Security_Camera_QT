#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<opencv4/opencv2/core.hpp>
#include<opencv4/opencv2/ml/ml.hpp>
#include<opencv4/opencv2/imgproc/imgproc.hpp>
#include<opencv4/opencv2/video/background_segm.hpp>
#include<opencv4/opencv2/videoio.hpp>
#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include<opencv2/imgcodecs.hpp>
#include<QDebug>
#include<QTimer>
#include <QSerialPort>
#include<QMouseEvent>
#include<QAccessibleObject>
#include <QTimer>
#include <QDateTime>
#include <QDate>
#include <QDebug>
#include <QSerialPortInfo>
#include <QTime>
#include <QSqlDatabase>
#include <QtSql>
#include <QSqlQuery>
#include <QtNetwork>
#include <QSqlError>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <qthread.h>
using namespace cv;

/*Variables Globales Declaradas*/
VideoCapture camara(0);
int NeWidth = 480;
int NewLength = 360;
Point Center1;
Point Center2;
bool Memory = false, j = true;
CascadeClassifier face_detaction;


void MainWindow::funcionCronometro()
{
    QDateTime date = QDateTime::currentDateTime();
    epochtime = date.toTime_t();
    Mat Cont, Cont2;
    Mat Image_1;
    Mat Image_2;
    Mat Image_3;
    Mat Gray;
    camara >> Image_1;
    if(!Image_1.empty())
    {
        int Width = Image_1.cols;
        int Length = Image_1.rows;
        double Proportion = (double) Width / Length;
        NeWidth = (int)360 * Proportion;
        NewLength = 360;
        cv::resize(Image_1, Image_2, Size(NeWidth, NewLength),0,0,0);
        cv::cvtColor(Image_2, Gray, COLOR_BGR2GRAY);
        if(ui -> checkBox -> isChecked())
        {
           cvtColor(Image_2,Image_2,COLOR_BGR2GRAY);
        }
        if(ui -> checkBox_2 -> isChecked())
        {
           cvtColor(Image_2,Image_2,COLOR_BGR2HSV);
        }
        if(ui -> checkBox_3 -> isChecked())
        {
           cvtColor(Image_2,Image_2,COLOR_BGR2Lab);
        }
        if(ui -> checkBox_4 -> isChecked())
        {
           cvtColor(Image_2,Image_2,COLOR_BGR2Luv);
        }
        cv::equalizeHist(Gray, Gray);
        std::vector<Rect> ObjectsFound;
        face_detaction.detectMultiScale(Gray,ObjectsFound,1.3,5,0|CASCADE_SCALE_IMAGE, Size(20,20));
        for (size_t i=0;i<ObjectsFound.size();i++)
        {
            if(i == 0)
            {
               Rect Region1;
               Point ObjectCenter(ObjectsFound[i].x+ObjectsFound[i].width/2, ObjectsFound[i].y+ObjectsFound[i].height/2);
               ellipse(Image_2, ObjectCenter, Size(ObjectsFound[i].width/2,ObjectsFound[i].height/2), 0,0, 360, Scalar(0,255,0),4, 8, 0);
               Region1.x = ObjectsFound[i].x;
               Region1.y = ObjectsFound[i].y;
               Region1.width = ObjectsFound[i].width;
               Region1.height = ObjectsFound[i].height;
               cv::resize(Image_2(Region1), Image_3,Size(480,380),0,0,0);
               if(j == true)
               {
                   QMessageBox::information(this, tr("MESSEGE"), tr("WE DETECTED A FACE"));
                   if(arduino->isWritable()){
                       arduino->write("0");
                   }else{
                       qDebug() << "Couldn't write to serial!";
                   }
                   QVariant valorLong = QVariant::fromValue(epochtime);
                   QString Image_Name= valorLong.toString()+".jpg";
                   cv::imwrite(Image_Name.toUtf8().constData(), Image_3);
                   image = Image_Name;
                   QSqlDatabase database = QSqlDatabase::addDatabase("QMYSQL");
                   database.setHostName("localhost");
                   database.setPort(3306);
                   database.setDatabaseName("Interfaces2021A");
                   database.setUserName("adminOmar");
                   database.setPassword("1618osgmar");
                   if(database.open())
                   {
                       //qDebug() << "La base de Datos se abrio.";
                       QString comandMYSQL = "INSERT INTO Proyecto(Fecha, Imagen) VALUES(?,?)";
                       QSqlQuery comand;
                       comand.prepare(comandMYSQL);
                       QVariant valorLong = QVariant::fromValue(epochtime);
                       comand.addBindValue(valorLong);
                       comand.addBindValue(image);
                       if(comand.exec())
                       {
                           qDebug() <<"El dato se Inserto Correctamente.";
                       }
                       else
                       {
                           qDebug() <<"No se puede Insertar Correctamente el Dato.";
                       }
                   }
                   else
                   {
                      qDebug() << "No se Pudo abrir la base de datos.";
                   }
                 j = false;

               }
            }
        }
        Image_2.copyTo(Cont);
        Cont2 = Image_3;
    }
    QImage Ig_1 = Mat2QImage(Cont);
    QPixmap Ig_2 = QPixmap::fromImage(Ig_1);
    ui -> label_2 -> setPixmap(Ig_2);
    QImage Ig_3 = Mat2QImage(Cont2);
    QPixmap Ig_4 = QPixmap::fromImage(Ig_3);
    ui -> label_6 -> setPixmap(Ig_4);
}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    if(!face_detaction.load("/home/omar/Desktop/Proyect/Proyect/HAAR/CaraFrontal.xml"));
    QTimer *cronometro = new QTimer(this);
    connect(cronometro, SIGNAL(timeout()), this, SLOT(funcionCronometro()));
    cronometro->start(30);
    arduino_is_available = false;
    arduino_port_name = "";
    arduino = new QSerialPort;


    qDebug() << "Number of available ports: " << QSerialPortInfo::availablePorts().length();
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        qDebug() << "Has vendor ID: " << serialPortInfo.hasVendorIdentifier();
        if(serialPortInfo.hasVendorIdentifier()){
            qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier();
        }
        qDebug() << "Has Product ID: " << serialPortInfo.hasProductIdentifier();
        if(serialPortInfo.hasProductIdentifier()){
            qDebug() << "Product ID: " << serialPortInfo.productIdentifier();
        }
    }


    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        if(serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier()){
            if(serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id){
                if(serialPortInfo.productIdentifier() == arduino_uno_product_id){
                    arduino_port_name = serialPortInfo.portName();
                    arduino_is_available = true;
                }
            }
        }
    }

    if(arduino_is_available){
        // open and configure the serialport
        arduino->setPortName(arduino_port_name);
        arduino->open(QSerialPort::WriteOnly);
        arduino->setBaudRate(QSerialPort::Baud9600);
        arduino->setDataBits(QSerialPort::Data8);
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop);
        arduino->setFlowControl(QSerialPort::NoFlowControl);
    }else{
        // give error message if not available
        QMessageBox::warning(this, "Port error", "Couldn't find the Arduino!");
    }
}


MainWindow::~MainWindow()
{
    delete ui;
}
